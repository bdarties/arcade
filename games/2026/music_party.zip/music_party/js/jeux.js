// Les 4 mini-jeux de Music Party. Les scènes communes (sélection, menu,
// choix des persos, résultats) lisent ces infos pour s'adapter au jeu choisi.
//   scene       : la scène du jeu         fond : image de fond du menu
//   choixPersos : false = pas d'écran de choix des persos (Music Fall : les Foxy)
//   image       : image de la carte sur l'écran de sélection
//   decor       : persos affichés sur les cotés du menu
//   croissant   : true = le plus PETIT score est le meilleur (Music Fall, en cm)

// les 4 persos d'opéra sur les cotés du menu
const DECOR_OPERA = [
  { texture: "img_carmen", x: 95, echelle: 0.62 },
  { texture: "img_figaro", x: 205, echelle: 0.62 },
  { texture: "img_diva", x: 1075, echelle: 0.62 },
  { texture: "img_maestro", x: 1185, echelle: 0.62 }
];

export const JEUX = [
  {
    cle: "music_fall",
    titre: "MUSIC FALL",
    slogan: "Tamponne ta note au plus près de la ligne dorée !",
    description: "Tamponne ta note\nau plus près de\nla ligne dorée !",
    regles:
      "Au top départ, ton perso tombe de sa feuille avec sa note.\n" +
      "Appuie sur A pour tamponner ta note sur la partition, au plus près\n" +
      "de la ligne dorée : 0 cm = parfait ! Si tu la dépasses : raté (60 cm).\n" +
      "3 essais : le plus petit total gagne.",
    scene: "music_fall",
    fond: "img_fond_scene",
    choixPersos: false,
    image: "img_renard",
    echelleImage: 4.5,
    decor: [
      { texture: "img_renard", x: 150, echelle: 4.5, anim: "anim_renard_repos" },
      { texture: "img_grenouille", x: 1060, echelle: 4.5, anim: "anim_grenouille_repos" },
      { texture: "img_renard2", x: 1180, echelle: 4.5, anim: "anim_renard2_repos" }
    ],
    unite: "cm",
    croissant: true
  },
  {
    cle: "piano_time",
    titre: "PIANO TIME",
    slogan: "Joue la mélodie sur le PIANO TIME géant !",
    description: "Joue la mélodie\nen rythme sur\nle PIANO TIME géant !",
    regles:
      "Les notes descendent vers la zone dorée de ton PIANO TIME.\n" +
      "Appuie sur A, B ou C quand une note est dans la zone :\n" +
      "chaque réussite accélère le tempo, le combo multiplie tes points.\n" +
      "3 notes ratées ou fausses notes : c'est fini !",
    scene: "piano_time",
    fond: "img_fond_scene",
    choixPersos: true,
    image: "img_figaro",
    echelleImage: 0.8,
    decor: DECOR_OPERA,
    unite: "pts",
    croissant: false
  }
];

// les infos d'un mini-jeu à partir de sa clé ("piano_time"...)
export function infosJeu(cle) {
  return JEUX.find((jeu) => jeu.cle == cle);
}
